package com.example.kaprekarnumber;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText numberInput;
    private Button checkButton;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberInput = findViewById(R.id.numberInput);
        checkButton = findViewById(R.id.checkButton);
        resultText = findViewById(R.id.resultText);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = numberInput.getText().toString();
                if (!input.isEmpty()) {
                    int number = Integer.parseInt(input);
                    boolean isKaprekar = isKaprekarNumber(number);
                    if (isKaprekar) {
                        resultText.setText(number + " is a Kaprekar number.");
                    } else {
                        resultText.setText(number + " is not a Kaprekar number.");
                    }
                } else {
                    resultText.setText("Please enter a number.");
                }
            }
        });
    }

    private boolean isKaprekarNumber(int num) {
        if (num == 1) {
            return true;
        }
        int numSquared = num * num;
        String numSquaredStr = Integer.toString(numSquared);
        int length = numSquaredStr.length();
        for (int i = 1; i < length; i++) {
            String leftPart = numSquaredStr.substring(0, i);
            String rightPart = numSquaredStr.substring(i);
            int leftNum = Integer.parseInt(leftPart);
            int rightNum = Integer.parseInt(rightPart);
            if (rightNum > 0 && leftNum + rightNum == num) {
                return true;
            }
        }
        return false;
    }
}